export enum Role {
    ADMIN = 'ADMIN',
    DIRECTOR = 'DIRECTOR',
    COMITE = 'COMITE',
    DOCENTE = 'DOCENTE',
}
